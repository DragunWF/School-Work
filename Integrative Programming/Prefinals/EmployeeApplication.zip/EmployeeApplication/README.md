# Employee Application

## Output

![Image of the output](images/Output.JPG)
